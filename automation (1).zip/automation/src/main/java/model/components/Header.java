package model.components;

import java.util.function.Supplier;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import model.base.Component;

public class Header extends Component {
	
    private Supplier<WebElement> chevronDown;
    private Supplier<WebElement> logoutButton;

	public Header(WebDriver driver) {
		super(driver, driver.findElement(By.cssSelector(".header-wrapper")));
		this.chevronDown = () -> findElement(By.cssSelector(".profile-name.hidden-xs .glyphicon-chevron-down"));
		this.logoutButton = () -> findElement(By.linkText("Logout"));
	}
	
	public WebElement chevronDown() {
		return chevronDown.get();
	}
	
	public WebElement logoutButton() {
		return logoutButton.get();
	}

}
