import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import model.LoginPage;
import model.components.Header;

public class LogoutTest extends BaseTest {
	
	@Test
	public void logoutTest() {
		driver.get(environment);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.successfullLogin();
        wait.until(ExpectedConditions.urlContains("/dashboard/home"));
        Header header = new Header(driver);
        header.chevronDown().click();
        wait.until(ExpectedConditions.elementToBeClickable(header.logoutButton()));
        header.logoutButton().click();
        wait.until(ExpectedConditions.elementToBeClickable(loginPage.signInButton()));
	}

}
