import model.LoginPage;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test
    public void successfulLoginTest() {
        driver.get(environment);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.successfullLogin();
        wait.until(ExpectedConditions.urlContains("/dashboard/home"));
    }

}
